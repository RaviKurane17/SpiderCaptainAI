#web_search.py
from utils.config import get_api_key
import json
import sys
import time
from pathlib import Path

# Module-level cached Gemini client — avoids recreating TCP/TLS connections
_gemini_client = None
_gemini_client_key = None

def _gemini_search(query: str) -> str:
    global _gemini_client, _gemini_client_key
    from google import genai

    key = get_api_key()
    if _gemini_client is None or _gemini_client_key != key:
        _gemini_client = genai.Client(api_key=key, http_options={"timeout": 10.0})
        _gemini_client_key = key

    response = _gemini_client.models.generate_content(
        model="gemini-2.5-flash",
        contents=query,
        config={"tools": [{"google_search": {}}]},
    )

    text = ""
    for part in response.candidates[0].content.parts:
        if hasattr(part, "text") and part.text:
            text += part.text

    text = text.strip()
    if not text:
        raise ValueError("Gemini returned an empty response.")
    return text


def _ddg_search(query: str, max_results: int = 6) -> list[dict]:
    try:
        from ddgs import DDGS
    except ImportError:
        from duckduckgo_search import DDGS

    results = []
    try:
        with DDGS(timeout=5) as ddgs:
            for r in ddgs.text(query, max_results=max_results):
                results.append({
                    "title":   r.get("title",  ""),
                    "snippet": r.get("body",   ""),
                    "url":     r.get("href",   ""),
                })
    except Exception as e:
        print(f"[WebSearch] DDG search failed: {e}")
    return results


def _format_ddg(query: str, results: list[dict]) -> str:
    if not results:
        return f"No results found for: {query}"

    lines = [f"Search results for: {query}\n"]
    for i, r in enumerate(results, 1):
        if r.get("title"):   lines.append(f"{i}. {r['title']}")
        if r.get("snippet"): lines.append(f"   {r['snippet']}")
        if r.get("url"):     lines.append(f"   {r['url']}")
        lines.append("")
    return "\n".join(lines).strip()

def _wiki_search(query: str, max_results: int = 3) -> list[dict]:
    import wikipedia
    results = []
    try:
        search_results = wikipedia.search(query, results=max_results)
        for t in search_results:
            try:
                page = wikipedia.page(t, auto_suggest=False)
                results.append({
                    "title": page.title,
                    "snippet": page.summary[:500] + "...",
                    "url": page.url
                })
            except Exception:
                pass
    except Exception as e:
        print(f"[WebSearch] Wikipedia search failed: {e}")
    return results

def _format_wiki(query: str, results: list[dict]) -> str:
    if not results:
        return f"No results found for: {query}"
    lines = [f"Wikipedia results for: {query}\n"]
    for i, r in enumerate(results, 1):
        lines.append(f"{i}. {r['title']}")
        lines.append(f"   {r['snippet']}")
        lines.append(f"   {r['url']}\n")
    return "\n".join(lines).strip()

def _compare(items: list[str], aspect: str) -> str:
    query = (
        f"Compare {', '.join(items)} in terms of {aspect}. "
        "Give specific facts and data."
    )
    try:
        return _gemini_search(query)
    except Exception as e:
        print(f"[WebSearch] ⚠️ Gemini compare failed: {e} — falling back to DDG")

    # DDG fallback: fetch results per item and merge
    all_results: dict[str, list] = {}
    for item in items:
        try:
            all_results[item] = _ddg_search(f"{item} {aspect}", max_results=3)
        except Exception:
            all_results[item] = []

    lines = [f"Comparison — {aspect.upper()}", "─" * 40]
    for item in items:
        lines.append(f"\n▸ {item}")
        for r in all_results.get(item, [])[:2]:
            if r.get("snippet"):
                lines.append(f"  • {r['snippet']}")
    return "\n".join(lines)

def web_search(
    parameters:     dict,
    response=None,
    player=None,
    session_memory=None,
) -> str:
    params = parameters or {}
    query  = params.get("query", "").strip()
    mode   = params.get("mode",  "search").lower().strip()
    items  = params.get("items", [])
    aspect = params.get("aspect", "general").strip() or "general"

    if not query and not items:
        return "Please provide a search query, sir."

    if items and mode != "compare":
        mode = "compare"

    if player:
        player.write_log(f"[Search] {query or ', '.join(items)}")

    print(f"[WebSearch] 🔍 Query: {query!r}  Mode: {mode}")

    try:
        deadline = time.monotonic() + 12.0   # aggregate 12s timeout

        if mode == "compare" and items:
            print(f"[WebSearch] 📊 Comparing: {items}")
            result = _compare(items, aspect)
            print("[WebSearch] ✅ Compare done.")
            return result

        print("[WebSearch] 🌐 Trying Gemini...")
        try:
            result = _gemini_search(query)
            print("[WebSearch] ✅ Gemini OK.")
            return result
        except Exception as e:
            print(f"[WebSearch] ⚠️ Gemini failed ({e}) — trying DDG...")
            if time.monotonic() > deadline:
                return f"Search timed out after Gemini failure, sir."
            try:
                results = _ddg_search(query)
                if not results:
                    raise ValueError("DDG returned no results")
                result  = _format_ddg(query, results)
                print(f"[WebSearch] ✅ DDG: {len(results)} result(s).")
                return result
            except Exception as e2:
                print(f"[WebSearch] ⚠️ DDG failed ({e2}) — trying Wikipedia...")
                if time.monotonic() > deadline:
                    return f"Search timed out after DDG failure, sir."
                results = _wiki_search(query)
                result = _format_wiki(query, results)
                print(f"[WebSearch] ✅ Wikipedia: {len(results)} result(s).")
                return result

    except Exception as e:
        print(f"[WebSearch] ❌ All backends failed: {e}")
        return f"Search failed, sir: {e}"