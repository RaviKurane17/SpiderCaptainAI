import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Mic, Send, StopCircle, ImageIcon, FileText, X, FileCode, Music, Film } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AttachedFile {
    name: string;
    type: string;
    size: number;
    dataUrl: string;
    fileType: 'image' | 'pdf' | 'code' | 'audio' | 'video' | 'other';
}

interface ChatComposerProps {
    input: string;
    setInput: (v: string) => void;
    isGenerating: boolean;
    onSend: () => void;
    onStop?: () => void;
    onFileAttach?: (file: AttachedFile, caption: string) => void;
    sendCommand?: (payload: object) => void;
}

function detectFileType(mime: string, name: string): AttachedFile['fileType'] {
    if (mime.startsWith('image/')) return 'image';
    if (mime === 'application/pdf') return 'pdf';
    if (mime.startsWith('audio/')) return 'audio';
    if (mime.startsWith('video/')) return 'video';
    const ext = name.split('.').pop()?.toLowerCase() || '';
    const codeExts = ['py','js','ts','tsx','jsx','html','css','java','c','cpp','cs','go','rs','sh','sql','json','yaml','toml','md','txt'];
    if (codeExts.includes(ext)) return 'code';
    return 'other';
}

function formatSize(bytes: number): string {
    if (bytes < 1024) return `${bytes}B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)}MB`;
}

export const ChatComposer: React.FC<ChatComposerProps> = ({
    input, setInput, isGenerating, onSend, onStop, sendCommand
}) => {
    const textareaRef  = useRef<HTMLTextAreaElement>(null);
    const imgInputRef  = useRef<HTMLInputElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [attachments, setAttachments] = useState<AttachedFile[]>([]);
    const [uploading,   setUploading]   = useState(false);

    useEffect(() => {
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
        }
    }, [input]);

    const readFile = (file: File): Promise<AttachedFile> =>
        new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload  = () => resolve({
                name: file.name,
                type: file.type,
                size: file.size,
                dataUrl: reader.result as string,
                fileType: detectFileType(file.type, file.name),
            });
            reader.onerror = () => reject(reader.error);
            reader.readAsDataURL(file);
        });

    const handleFiles = useCallback(async (files: FileList | null) => {
        if (!files || files.length === 0) return;
        setUploading(true);
        try {
            const loaded = await Promise.all(Array.from(files).map(readFile));
            setAttachments(prev => [...prev, ...loaded].slice(0, 5)); // max 5 files
        } catch (e) {
            console.error('File read error:', e);
        } finally {
            setUploading(false);
        }
    }, []);

    const handleDrop = useCallback((e: React.DragEvent) => {
        e.preventDefault();
        handleFiles(e.dataTransfer.files);
    }, [handleFiles]);

    const removeAttachment = useCallback((idx: number) => {
        setAttachments(prev => prev.filter((_, i) => i !== idx));
    }, []);

    const handleSend = useCallback(() => {
        if (!input.trim() && attachments.length === 0) return;

        if (attachments.length > 0 && sendCommand) {
            // Send each attachment as a file analysis request
            attachments.forEach(att => {
                const caption = input.trim() || `Analyze this ${att.fileType}: ${att.name}`;
                sendCommand({
                    type: 'analyze_file',
                    file_name: att.name,
                    file_type: att.fileType,
                    mime_type: att.type,
                    data_url: att.dataUrl,
                    caption,
                });
            });
            setAttachments([]);
            setInput('');
        } else {
            onSend();
        }
    }, [input, attachments, sendCommand, onSend, setInput]);

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    const FileIcon = ({ ft }: { ft: AttachedFile['fileType'] }) => {
        if (ft === 'image') return <ImageIcon className="h-4 w-4" />;
        if (ft === 'code')  return <FileCode className="h-4 w-4" />;
        if (ft === 'audio') return <Music className="h-4 w-4" />;
        if (ft === 'video') return <Film className="h-4 w-4" />;
        return <FileText className="h-4 w-4" />;
    };

    return (
        <div
            className="p-4 bg-black/20 border-t border-white/5 backdrop-blur-xl relative"
            onDragOver={e => e.preventDefault()}
            onDrop={handleDrop}
        >
            {/* Hidden file inputs */}
            <input
                ref={imgInputRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={e => handleFiles(e.target.files)}
            />
            <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.txt,.md,.py,.js,.ts,.tsx,.jsx,.html,.css,.java,.c,.cpp,.cs,.go,.rs,.sh,.sql,.json,.yaml,.toml,.csv,.xlsx,.docx,.pptx,.mp3,.wav,.mp4,.avi"
                multiple
                className="hidden"
                onChange={e => handleFiles(e.target.files)}
            />

            <div className="max-w-4xl mx-auto flex flex-col gap-2 relative">

                {/* Attachment Previews */}
                {attachments.length > 0 && (
                    <div className="flex gap-2 flex-wrap pb-1">
                        {attachments.map((att, idx) => (
                            <div
                                key={idx}
                                className="group relative flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs"
                            >
                                {att.fileType === 'image' ? (
                                    <img
                                        src={att.dataUrl}
                                        alt={att.name}
                                        className="h-8 w-8 object-cover rounded"
                                    />
                                ) : (
                                    <div className="h-8 w-8 flex items-center justify-center bg-[var(--cyan)]/10 rounded text-[var(--cyan)]">
                                        <FileIcon ft={att.fileType} />
                                    </div>
                                )}
                                <div className="flex flex-col max-w-[120px]">
                                    <span className="truncate font-medium text-foreground">{att.name}</span>
                                    <span className="text-muted-foreground">{formatSize(att.size)}</span>
                                </div>
                                <button
                                    onClick={() => removeAttachment(idx)}
                                    className="absolute -top-1.5 -right-1.5 h-4 w-4 rounded-full bg-rose-500 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition"
                                >
                                    <X className="h-2.5 w-2.5" />
                                </button>
                            </div>
                        ))}
                        {uploading && (
                            <div className="flex items-center gap-2 text-xs text-muted-foreground px-2">
                                <div className="h-3 w-3 rounded-full border border-[var(--cyan)] border-t-transparent animate-spin" />
                                Reading file...
                            </div>
                        )}
                    </div>
                )}

                <div className="relative">
                    <textarea
                        ref={textareaRef}
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={handleKeyDown}
                        placeholder={attachments.length > 0 ? "Add a caption or question about the file..." : "Ask CAPTAIN AI..."}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 min-h-[56px] max-h-48 resize-none text-sm text-foreground focus:outline-none focus:border-white/20 focus:ring-1 focus:ring-white/20 transition-all placeholder:text-muted-foreground pr-32 custom-scrollbar shadow-inner"
                        rows={1}
                    />

                    {/* Character Counter */}
                    <div className="absolute left-4 -bottom-5 text-[9px] font-mono text-muted-foreground tracking-widest uppercase">
                        {input.length} chars
                    </div>

                    <div className="absolute right-2 top-2 flex items-center gap-1">
                        <button
                            onClick={() => imgInputRef.current?.click()}
                            className="p-2 text-muted-foreground hover:text-[var(--cyan)] transition rounded-md hover:bg-white/10"
                            title="Attach Image"
                        >
                            <ImageIcon className="h-4 w-4" />
                        </button>
                        <button
                            onClick={() => fileInputRef.current?.click()}
                            className="p-2 text-muted-foreground hover:text-[var(--cyan)] transition rounded-md hover:bg-white/10"
                            title="Attach PDF / File"
                        >
                            <FileText className="h-4 w-4" />
                        </button>
                        <div className="w-px h-4 bg-white/10 mx-1" />
                        <button className="p-2 text-muted-foreground hover:text-white transition rounded-md hover:bg-white/10" title="Voice Input">
                            <Mic className="h-4 w-4" />
                        </button>

                        {isGenerating ? (
                            <button
                                onClick={onStop}
                                className="p-2 ml-1 bg-rose-500/20 text-rose-400 hover:bg-rose-500/40 hover:text-rose-300 transition rounded-md"
                            >
                                <StopCircle className="h-4 w-4" />
                            </button>
                        ) : (
                            <button
                                onClick={handleSend}
                                disabled={!input.trim() && attachments.length === 0}
                                className="p-2 ml-1 bg-[var(--cyan)]/20 text-[var(--cyan)] hover:bg-[var(--cyan)]/40 hover:text-[oklch(0.85_0.22_225)] transition rounded-md disabled:opacity-30 disabled:hover:bg-[var(--cyan)]/20 disabled:hover:text-[var(--cyan)]"
                            >
                                <Send className="h-4 w-4" />
                            </button>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};
